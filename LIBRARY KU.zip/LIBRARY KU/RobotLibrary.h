#ifndef ROBOTLIBRARY_H
#define ROBOTLIBRARY_H

#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>
#include <EEPROM.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define SCREEN_ADDRESS 0x3C

#define OLED_RESET -1
extern Adafruit_SSD1306 lcd;

#define pin_A_mux A1
#define pin_B_mux A2
#define pin_C_mux A3
#define pin_X_mux A7

#define pin_dir_motor_L 9
#define pin_pwm_motor_L 5
#define pin_dir_motor_R 10
#define pin_pwm_motor_R 6

#define pin_button_OK A0
#define pin_button_DOWNL 8
#define pin_button_UPR 11
#define pin_button_DOWNR 12

#define button_OK digitalRead(pin_button_OK)
#define button_DOWNL digitalRead(pin_button_DOWNL)
#define button_UPR digitalRead(pin_button_UPR)
#define button_DOWNR digitalRead(pin_button_DOWNR)

extern boolean A[8];
extern boolean B[8];
extern boolean C[8];

extern char buff[100];
extern int index_menu;
extern int run_speed;
extern byte Kp;
extern byte Ki;
extern byte Kd;
extern boolean polMotor_L;
extern boolean polMotor_R;

#define GARIS_HITAM 0
#define GARIS_PUTIH 1

#define OR 1
#define XOR 2

struct dataSetting {
  int speed;
  byte kp;
  byte ki;
  byte kd;
  unsigned int calibration_value[8];
  char name[15];
};

extern dataSetting setting;
extern bool robotRunning;

void begin();
void Loop();
void saveSetting();
void loadSetting();
void polaritasMotor(boolean left, boolean right);
void setPID(byte p, byte i, byte d);
byte readSensor();
void setMotor(int LL, int RR);
void followLine(byte dataSensor);
void calibrate_sensor();
void navigateMenu();
int setSpeed();
void setKp();
void setKi();
void setKd();
void displaySensor();
void RobotLoop();

#endif // ROBOTLIBRARY_H
